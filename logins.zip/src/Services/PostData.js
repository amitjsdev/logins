module.exports= {
    BaseUrl : "https://us-central1-oyolife-2ce61.cloudfunctions.net/app"
}