import RoomPic from './Dummy.jpeg';
export const RoomImage = RoomPic