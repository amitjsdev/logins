
import React from 'react';
import { Modal, Row, Col, Button, Layout, Menu, Card, Alert } from 'antd';
import MobileAuth from "./MobileAuth";
import { connect } from 'react-redux';
import { setUser } from './Home/store/HomeActions'
const { Header, Footer, Sider } = Layout;

class AuthComponent extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            modal1Visible: false,
            modal2Visible: false,
            currentUser: null,
            auth: '',
            auth_type: '',
            email: '',
            first_name: '',
            id: '',
            last_name: '',
            name: '',
            profile: '',
            token: '',
            phoneModal: null,
            loginPopup: null,
            authVal: this.props.auth,
            signInWithGoogle: this.props.signInWithGoogle,
            invitedUrl: this.props.invitedUrl,
        };


        // const SENDER_UID = 'USER1234';
        // //build the link
        // const link = `https://www.deeplinkdemo.com?invitedBy=${SENDER_UID}`;
        // const dynamicLinkDomain = 'https://deeplinkblogdemo.page.link';
        // //call  DynamicLink constructor
        // const DynamicLink = new this.props.firebase.links.DynamicLink(link, dynamicLinkDomain);
        // //get the generatedLink
        // const generatedLink =  this.props.firebase.links().createDynamicLink(DynamicLink);
        // console.log('created link', generatedLink);

    }




    //user
    //google login
    unsubscribeFromAuth = null;

    async componentDidMount() {
        this.unsubscribeFromAuth = this.state.authVal.onAuthStateChanged(user => {
            this.setState({ currentUser: user }, () => {
                console.log("currentUser", this.state.currentUser);


            });

        })

        //get data
        //   let url = await this.props.firebase.links().getInitialLink();
        //     console.log('incoming url', url); //incoming url https://www.deeplinkdemo.com?invitedby=USER1234
        //     if (url) {
        //     const ID = this.getParameterFromUrl(url, "invitedBy");
        //     console.log('ID', ID); //ID USER1234
        //     }
    }

    // getParameterFromUrl(url, parm) {
    //     var re = new RegExp(".*[?&]" + parm + "=([^&]+)(&|$)");
    //     var match = url.match(re);
    //     return (match ? match[1] : "");
    // }

    componentWillUnmount() {
        this.unsubscribeFromAuth();
    }
    //google end
    checkUserExist = async (mail) => {
        const db = this.props.firebase.firestore();
        const citiesRef = db.collection('users');
        const snapshot = await citiesRef.where('email', '==', mail).get();
        if (snapshot.empty) {
            return false;
        }
        let datum;
        snapshot.forEach(doc => {
            datum = doc.data()
            datum.dbId = doc.id
            console.log(doc.id, '=>', doc.data());
        });
        return datum;
    }

    insertIntoDb = async (data) => {
        const db = this.props.firebase.firestore();
        const citiesRef = db.collection('users');
        const snapshot = await citiesRef.add(data);

        return snapshot;
    }

    updateReduxStore = (data) => {
        this.props.setUser(data)
    }

    loginWithGoogleClickHandler = async () => {
        const firebase = this.props.firebase;
        const provider = new firebase.auth.GoogleAuthProvider();
        provider.setCustomParameters({ prompt: 'select_account' });
        firebase.auth().signInWithPopup(provider).then(async (resp) => {
            this.props.ShowUserPopoup();
            console.log({ resp })
            const mail = resp.user.email;
            const isExistinDb = await this.checkUserExist(mail);
            console.log('isExistinDb', isExistinDb);
            if (isExistinDb) {
                this.updateReduxStore(isExistinDb)
                //update redux store 
            } else {
                let data = {
                    email: resp.user.email,
                    name: resp.user.displayName,
                    picture: resp.user.picture ? resp.user.picture : '',
                    auth_type: 'google',
                    referral: resp.user.uid,
                    invited: [this.state.invitedUrl],
                }
                console.log({ data })
                const isInserted = await this.insertIntoDb(data);
                if (isInserted && isInserted.id) {
                    data.dbId = isInserted.id;
                    this.updateReduxStore(data)
                    //update redux store  
                }

            }


        })

    }

    phoneAuthHandler = async () => {
        this.setState({ phoneModal: true })
    }
    PhoneCallback = async (number) => {
        const isExist = this.checkUserExist(number);
        if (!isExist) {
            let data = {
                email: number,
                name: '',
                picture: '',
                auth_type: 'phone'
            }
            const isInserted = await this.insertIntoDb(data)
            if (isInserted) {
                this.updateReduxStore(isInserted)
            } else {
                this.setState({ error: true, errorMessage: '', phoneModal: false })
            }
        } else {
            this.updateReduxStore(isExist)
            this.setState({ phoneModal: false })
        }

    }

    fbAuthHandler = async () => {

    }

    setModal2Visible(modal2Visible) {
        this.setState({ modal2Visible });
    }


    render() {

        return (
            <> <div id="recaptcha-container" className="recaptcha-container"></div>


                <Modal
                    visible={this.state.loginPopup}
                    //closable={false}
                    footer={false}
                    zIndex={1000}
                    onCancel={e => this.setState({ loginPopup: false })}
                >
                    <div className='user-info'>
                        {

                            this.state.currentUser ?

                                (<div>
                                    <div>
                                        <img src={this.state.currentUser.photoURL} />
                                    </div>
                                    <div>Name: {this.state.currentUser.displayName}</div>
                                    <div>Email: {this.state.currentUser.email}</div>
                                    <div>Referral: {window.location.hostname + '/' + this.state.currentUser.uid}</div>


                                    <button onClick={() => this.state.auth.signOut()}>LOG OUT</button>
                                </div>
                                ) :
                                null

                        }
                    </div >
                </Modal>

                <Modal
                    visible={this.state.phoneModal}
                    //closable={false}
                    footer={false}
                    zIndex={1000}
                    onCancel={e => this.setState({ phoneModal: false })}
                >
                    <MobileAuth firebase={this.props.firebase} callback={this.PhoneCallback} />
                </Modal>
                <Modal
                    visible={this.props.showLoginPopoup}
                    closable={false}
                    footer={false}
                    zIndex={999}
                >
                    <Card>
                        <h1 className="heading">Get Start</h1>
                        <Alert type="info" message="By clicking Log in, you agree to our Terms.Learn how we process your data in our Privacy Policy. and Cookie Policy" />
                        <div className="row">
                            <Card >
                                <Button onClick={this.fbAuthHandler}
                                    type="primary"
                                    shape="round"
                                    size="large"
                                >Log in with  Facebook</Button>
                            </Card>
                        </div>
                        <div className="row">
                            <Card >
                                <Button onClick={this.loginWithGoogleClickHandler}
                                    type="primary"
                                    shape="round"
                                    size="large"
                                >Log in with Google </Button>
                            </Card>
                        </div>
                        <div className="row">
                            <Card >
                                <Button onClick={this.phoneAuthHandler}
                                    type="primary"
                                    shape="round"
                                    size="large"
                                >Log in with Phone Number
                   </Button>
                            </Card>
                        </div>
                    </Card>
                </Modal>
            </>

        );
    }
}
const mapStateToProps = state => {
    return {
        data: state.home.data,
    };
};

const mapDispatchToProps = dispatch => {
    return {
        setUser: payload => dispatch(setUser(payload)),
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(AuthComponent)