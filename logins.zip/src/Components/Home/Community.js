
import React from 'react';
import { Modal, Button } from 'antd';
import { Card, Col, Row } from 'antd';
import { Alert } from 'antd';
import { Steps, message } from 'antd';
import { Typography } from 'antd';
import Step1 from './Step1';
import Step2 from './Step2';
import Step3 from './Step3';
import { RightCircleOutlined, FacebookOutlined, WhatsAppOutlined, MessageOutlined } from '@ant-design/icons';
const { Title } = Typography;
const { Step } = Steps;
class Community extends React.Component {
  state = {
    modal2Visible: false,
    current: 0,
    data:{}
  };

  setModal2Visible(modal2Visible) {
    this.setState({ modal2Visible });
  }


  next = (payload) => {
    let { data } = this.state;
    data[payload.step] = payload;
    this.setState({ data, current: payload.step  })
  };


  render() {
    const { current } = this.state;
    const steps = [
      {
        title: 'First',
      },
      {
        title: 'Second',
      },
      {
        title: 'Last',
      },
    ];
    return (
      <>
        <div style={{testAlign:'center',backgroundColor:'azure', height:'80vh', width:'80%', margin:'0 auto', borderRadius:'30px', padding:'30px'}}>
        <div class="elementor-background-overlay"></div>
        <h1 class="elementor-heading-title elementor-size-default">
            Share with two mother's to have  them join the community
        </h1>
        
        <Button
              style={{margin:'60px auto'}}
              type="primary"
              size="large"
              shape="round"
              icon={<RightCircleOutlined />}
              danger={true}
              onClick={() => this.setModal2Visible(true)}
            >
              Share the redeem code
            </Button>
        
        <Modal
          title={null}
          centered
          visible={this.state.modal2Visible}
          onOk={() => this.setModal2Visible(false)}
          onCancel={() => this.setModal2Visible(false)}
          closeIcon={false}
          closable={false}
          width={500}
          footer={null}
        >
          <Card title={<Alert message={<Title level={6} style={{width:'100%', textAlign:'center'}}>Share with</Title>} type="info" />} bordered={false}>
            
           
               <Button className="ant-btn-share"><FacebookOutlined style={{color:'#34b7f1',fontSize: '36px'}} />facebook</Button>
              
               <Button className="ant-btn-share" > <WhatsAppOutlined  style={{color:'#dcf8c6',fontSize: '36px'}}/>whatsapp</Button>
               
               <Button  className="ant-btn-share"><MessageOutlined  style={{color:'#25d366',fontSize: '36px'}}/>message</Button>
              
           </Card>

          
        </Modal>
        </div>
      </>
    );
  }
}

export default Community;