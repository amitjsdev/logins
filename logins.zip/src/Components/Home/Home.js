import React from 'react'
import { connect } from 'react-redux';
import Community from './Community';
import CompleteSignup from './CompleteSignup';
class Home extends React.Component {
    constructor(props) {
        super(props);
        this.state={
            
        }

    }

    complete =async(data)=>{
        
        let {user}=this.props;
        console.log(data, user);
        user ={...user, ...data}
        console.log(user);
        const db = this.props.firebase.firestore();
        const res = await db.collection('users').doc(user.dbId).set(user);
        console.log(res);
        this.setState({signUpCompleted:true})
    }

    render() {
        const {user} =this.props;

        return (
            <>
                {
                    user && user.signUpCompleted ? <Community user={user}/> : <CompleteSignup complete={this.complete}  user={user}/>
                }
            </>
        );
    }
}

const mapStateToProps = state => {
    return {
        user: state.home.user,
        isAuthenticated: state.home.isAuthenticated,
    };
};

const mapDispatchToProps = dispatch => {
    return {
        //getUsers: () => dispatch(getUsers()),
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(Home)
