import React, { Component } from "react";
import 'firebase/firestore';
import { auth } from '../../firebase/firebase.utils';
import firebase from '../../firebase/firebase.utils';
import firestore from 'firebase/firestore'
import { FormGroup, Input } from "reactstrap";
import useFirebase from "../../Services/firebase";
import { navigate } from "@reach/router";
import OTPIcon from "../../assets/images/signin/otp-icon.png";
import firebaseComponent from "@firebase/app";
import axios from "axios";
//import Loader from "../Loader";
import url from "../../Services/PostData";
import Close from "../../assets/images/admin/close.svg";
import constant from "../../Services/constant.json";
import { Modal, Row, Col, Button, Layout, Menu } from 'antd';

let confirmCode = "";
class OTP extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      modal1Visible: false,
      modal2Visible: false,
      show: false,
      otp1: "",
      userEmail:"",
      number: "",
      loader: false,
      email:'',

    };
    console.log("props--", localStorage.getItem("number"));
  }

  setModal1Visible(modal1Visible) {
    this.setState({ modal1Visible });
  }
  setModal2Visible(modal2Visible) {
    //console.log("modal2Visible",modal2Visible);
    this.setState({ modal2Visible });
  }
  componentDidMount() {
    this.setState({
      number: `+91${localStorage.getItem("number")}`,
    });
    console.log("number", localStorage.getItem("number"))
     this.verifyNumber(`+91${localStorage.getItem("number")}`);
  }

  verifyNumber = (number) => {
    console.log("number", number)
    this.SetUpReCaptcha();
    let appVerifier = window.recaptchaVerifier;
    !!firebase &&
      firebase
        .auth()
        .signInWithPhoneNumber(number, appVerifier)
        .then(function (confirmationResult) {
          confirmCode = confirmationResult;
          console.log("confirmation", confirmationResult, confirmCode);
        })
        .catch(function (error) {
          console.log("eeeeeeee", error);
        });
  };

  SetUpReCaptcha = () => {
    window.recaptchaVerifier = new firebaseComponent.auth.RecaptchaVerifier(
      "recaptcha-container",
      {
        size: "invisible",
        callback: function (response) {
          this.verifyNumber();
        },
      }
    );
  };

  handleCode = (confirmationResult) => {
    const { userEmail,otp1, number, loader } = this.state;
    console.log("otp", otp1, number);
    window.confirmationResult = confirmationResult;
    var code = otp1;
    confirmationResult
      .confirm(code)
      .then(async function (result) {
        console.log("accept");
        //var user = result.user;
        await axios.get(url.BaseUrl + "/api/doc/" + number).then((response) => {
          console.log(!response.data);
          if (!response.data) {
            navigate("/register");
          } else {
            localStorage.setItem("authentication", true);
            localStorage.setItem("name", response.data.name);
            localStorage.setItem("email", response.data.email);
            let path = localStorage.getItem('navigatePrivate')
            navigate(path);
          }
        });
      })
      .catch((error) => {
        console.log("error", error);
      });
  };

  handleShow = () => {
    this.setState({ show: true });
  };
  handleClose = () => {
    this.setState({ show: false });
  };

  handleOTP = (e) => {
    console.log("taret", e.target.value);
    this.setState({
      otp1: e.target.value,
    });
  };

  handleEmail = (e) => {
    console.log("taret", e.target.value);
    this.setState({
      userEmail: e.target.value,
    });
  };

  confirmOTP = () => {
    this.setState({
      loader: true,
    });
      this.handleCode(confirmCode);
  };

  handleCloseOtp = () => {
    navigate("/");
  }

  handleVerifyOTP = (event) => {
    if (event.key === "Enter") {
      this.setState({
        loader: true,
      });
        this.handleCode(confirmCode);
    }
  };

  SubmitEmail = async () => {
console.log("this.state.userEmail",this.state.userEmail);
  this.ref = firebase.firestore().collection('users');
    const db = firebase.firestore();
    const citiesRef = db.collection('users');
    const email = this.state.userEmail
    const phone = this.state.number
    const snapshot = await citiesRef.where('email', '==', email).get();
    if (snapshot.empty) {
      console.log("this.state.val",this.state.userEmail);
      this.ref.add({
        email,
        phone,
      }).then((docRef) => {
        console.log("login successful");
        // this.props.history.push("/")
      })
        .catch((error) => {
          console.error("Error adding document: ", error);
        });
      return;
    }
  }

  render() {
    const { otp1, loader } = this.state;
    console.log("otp11", this.state, otp1);
    return (
      <>
      <div className="login-page">
        <div className="login-wrapper">
          <button className="close-btn" onClick={this.handleCloseOtp}>
            <img src={Close} />
          </button>
          <div className="icon">
            <img src={OTPIcon} />
          </div>

          <h2> Verification</h2>
          <p className="mb-4 pb-3">You will get an OTP via SMS</p>

          <div id="recaptcha-container"></div>
          <FormGroup className="mb-4">
            <Input
              type="number"
              name="otp"
              placeholder="Enter Otp"
              onChange={(e) => this.handleOTP(e)}
              onKeyDown={(e) => this.handleVerifyOTP(e)}
            />
          </FormGroup>

          {!loader ? (<button className="verify-btn" onClick={this.confirmOTP}>
            Verify
          </button>) : null}
        </div>

        
      </div>
      <Modal
          visible={this.state.modal2Visible}
       
        >
          <Input
              type="email"
              name="userEmail"
              placeholder="Enter Email"
              onChange={(e) => this.handleEmail(e)}
            />
          (<button className="verify-btn" onClick={this.SubmitEmail}>
            Submit
          </button>)
        </Modal>
      </>
    );
  }
}
export default OTP;
