
import React from 'react';
import { Modal, Row, Col, Button, Layout, Menu } from 'antd';
import logo from '../assets/img/logo512.png';
import "./AppHeader.css";
const { Header } = Layout;

class AppHeader extends React.Component {
  constructor(props){
    super(props);
  }

  render() {

    return (

      <Header>
        <Row >
          <Col span={8}><div className="logo" ><img src={logo} height="40px" /></div></Col>

          <Col span={8} offset={8}>
            <div style={{ float: 'right' }} >
              <Button onClick={this.props.showLoginPopoup}

                type="danger"
                shape="round"
                size="large"
              >LOG IN
                   </Button>

            </div>

          </Col>
        </Row>
      </Header>

    );
  }
}

export default AppHeader;
