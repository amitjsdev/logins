import React, { Component } from 'react';
import {
  BrowserRouter as Router,
  Redirect,
  Switch,
  Route,
} from 'react-router-dom';

import HomePage from "./App";
import otp from "./Components/Login/Otp.js";

class Routes extends Component {
	constructor(props){
		super(props);
		this.state = {
			userCount: 0
		}
	}

  render() {
    return (
	<Router>  
     <div> 
	  <Switch>
  <Route  exact path="/" component={HomePage} />} />
        <Route exact path="/otp" component={otp} />
		<Redirect to="/" />
      </Switch>
      </div>  
  </Router> 
    );
  }
}

export default Routes;